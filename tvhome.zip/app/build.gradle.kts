plugins {
    id("com.android.application")
}

android {
    namespace = "com.tahrim.tvhome"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tahrim.tvhome"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
