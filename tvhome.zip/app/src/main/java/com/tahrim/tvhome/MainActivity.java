package com.tahrim.tvhome;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        web.setInitialScale(100);
        web.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        web.setBackgroundColor(Color.BLACK);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();

        requestMediaPermissions();
        askOverlayOnce();
    }

    // Needed so the app is allowed to open by itself when the TV starts.
    private void askOverlayOnce() {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            if (Settings.canDrawOverlays(this)) return;
            SharedPreferences sp = getSharedPreferences("tvhome", MODE_PRIVATE);
            if (sp.getBoolean("askedOverlay", false)) return;
            sp.edit().putBoolean("askedOverlay", true).apply();
            Toast.makeText(this, "Allow \"Display over other apps\" so this app can open when the TV starts", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.requestFocus();
            web.evaluateJavascript("window.refreshAll&&window.refreshAll()", null);
        }
    }

    @Override
    public void onBackPressed() {
        // This is a home screen: Back only closes panels inside the page.
        web.evaluateJavascript("window.onBack&&window.onBack()", null);
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermissions() {
        if (hasMediaPermission()) return;
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_AUDIO}, 11);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 11);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        web.evaluateJavascript("window.refreshAll&&window.refreshAll()", null);
    }

    private long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long n = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) n += dirSize(k);
        return n;
    }

    private void deleteContents(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory()) deleteContents(k);
            //noinspection ResultOfMethodCallIgnored
            k.delete();
        }
    }

    private String statsJson(long freedBytes) {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            JSONObject o = new JSONObject();
            o.put("ramTotal", mi.totalMem);
            o.put("ramAvail", mi.availMem);
            o.put("stTotal", sf.getTotalBytes());
            o.put("stFree", sf.getAvailableBytes());
            o.put("freed", freedBytes);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private boolean launchPackage(String pkg) {
        PackageManager pm = getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void openStoreSearch(String name) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(name) + "&c=apps"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, name + " is not installed", Toast.LENGTH_LONG).show();
        }
    }

    private void openFirst(String label, String... packages) {
        for (String p : packages) {
            if (launchPackage(p)) return;
        }
        openStoreSearch(label);
    }

    public class Bridge {

        @JavascriptInterface
        public String getStats() {
            return statsJson(0);
        }

        @JavascriptInterface
        public String clearRam() {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo before = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(before);
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            for (ApplicationInfo a : apps) {
                if (a.packageName.equals(getPackageName())) continue;
                if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                try {
                    am.killBackgroundProcesses(a.packageName);
                } catch (Exception ignored) {
                }
            }
            try {
                Thread.sleep(900);
            } catch (InterruptedException ignored) {
            }
            ActivityManager.MemoryInfo after = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(after);
            long freed = Math.max(0, after.availMem - before.availMem);
            return statsJson(freed);
        }

        @JavascriptInterface
        public String cleanCache() {
            long size = dirSize(getCacheDir()) + dirSize(getExternalCacheDir());
            deleteContents(getCacheDir());
            deleteContents(getExternalCacheDir());
            runOnUiThread(() -> web.clearCache(true));
            return statsJson(size);
        }

        @JavascriptInterface
        public void openStorageSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Settings.ACTION_SETTINGS);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_SETTINGS);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Settings not available", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void openApp(final String key) {
            runOnUiThread(() -> {
                switch (key) {
                    case "live":
                        openFirst("Live TV", "com.google.android.tv", "com.google.android.apps.tv.livetv", "com.android.tv");
                        break;
                    case "youtube":
                        openFirst("YouTube", "com.google.android.youtube.tv", "com.google.android.youtube");
                        break;
                    case "toffee":
                        openFirst("Toffee", "com.banglalink.toffee");
                        break;
                    case "web":
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } catch (Exception e) {
                            openStoreSearch("Web Browser");
                        }
                        break;
                    default:
                        break;
                }
            });
        }

        @JavascriptInterface
        public void openUri(final String uri, final String mime) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(uri), mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No app found to open this file", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open this file", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String getAppIcon(String key) {
            String[] pkgs;
            if ("youtube".equals(key)) pkgs = new String[]{"com.google.android.youtube.tv", "com.google.android.youtube"};
            else if ("toffee".equals(key)) pkgs = new String[]{"com.banglalink.toffee"};
            else if ("live".equals(key)) pkgs = new String[]{"com.google.android.tv", "com.google.android.apps.tv.livetv", "com.android.tv"};
            else return "";
            for (String pkg : pkgs) {
                try {
                    android.graphics.drawable.Drawable d = getPackageManager().getApplicationIcon(pkg);
                    Bitmap bm = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas c = new android.graphics.Canvas(bm);
                    d.setBounds(0, 0, 192, 192);
                    d.draw(c);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.PNG, 100, bos);
                    return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                } catch (Exception ignored) {
                }
            }
            return "";
        }

        @JavascriptInterface
        public boolean hasMediaAccess() {
            return hasMediaPermission();
        }

        @JavascriptInterface
        public String getRecent() {
            JSONArray out = new JSONArray();
            if (!hasMediaPermission()) return out.toString();
            try {
                List<Item> all = new ArrayList<>();
                query(all, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video");
                query(all, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "photo");
                query(all, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "music");
                Collections.sort(all, new Comparator<Item>() {
                    @Override
                    public int compare(Item a, Item b) {
                        return Long.compare(b.added, a.added);
                    }
                });
                int n = Math.min(4, all.size());
                for (int k = 0; k < n; k++) {
                    Item it = all.get(k);
                    JSONObject o = new JSONObject();
                    o.put("name", it.name);
                    o.put("kind", it.kind);
                    o.put("uri", it.uri.toString());
                    o.put("mime", it.mime);
                    o.put("meta", it.meta);
                    o.put("thumb", thumb(it));
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }
    }

    private static class Item {
        String name;
        String kind;
        String mime;
        String meta;
        long added;
        Uri uri;
    }

    private void query(List<Item> into, Uri base, String kind) {
        try {
            Bundle args = new Bundle();
            args.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{MediaStore.MediaColumns.DATE_ADDED});
            args.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            args.putInt(ContentResolver.QUERY_ARG_LIMIT, 4);
            String[] proj = {
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.MediaColumns.MIME_TYPE,
                    MediaStore.MediaColumns.DURATION
            };
            if (kind.equals("photo")) {
                proj = new String[]{
                        MediaStore.MediaColumns._ID,
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_ADDED,
                        MediaStore.MediaColumns.MIME_TYPE
                };
            }
            Cursor c = getContentResolver().query(base, proj, args, null);
            if (c == null) return;
            try {
                while (c.moveToNext()) {
                    Item it = new Item();
                    long id = c.getLong(0);
                    it.name = c.getString(1);
                    it.added = c.getLong(2);
                    it.mime = c.getString(3);
                    it.kind = kind;
                    it.uri = ContentUris.withAppendedId(base, id);
                    if (kind.equals("photo")) {
                        it.meta = "Photo";
                    } else {
                        long ms = c.isNull(4) ? 0 : c.getLong(4);
                        long sec = ms / 1000;
                        String t = (sec / 60) + ":" + String.format("%02d", sec % 60);
                        it.meta = (kind.equals("video") ? "Video · " : "Music · ") + t;
                    }
                    if (it.mime == null) {
                        it.mime = kind.equals("video") ? "video/*" : kind.equals("photo") ? "image/*" : "audio/*";
                    }
                    into.add(it);
                }
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
    }

    private String thumb(Item it) {
        if (Build.VERSION.SDK_INT < 29 || it.kind.equals("music")) return "";
        try {
            Bitmap bm = getContentResolver().loadThumbnail(it.uri, new Size(416, 234), null);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 70, bos);
            return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }
}
